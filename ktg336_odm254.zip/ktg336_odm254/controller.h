
void Controller_Init(void);
unsigned long get_buttons(void);


void ADC_Init(unsigned char channelNum);
unsigned long ADC_In(void);


void Sound_Init(void);
void playWAV(unsigned char *, unsigned int, unsigned int);

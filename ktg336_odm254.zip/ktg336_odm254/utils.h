
void random_init(unsigned long);
unsigned long random_int(void);
unsigned long log2(unsigned long);

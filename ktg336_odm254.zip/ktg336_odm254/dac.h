
extern void DAC_Init(void);
extern void DAC_Out(int val);
